package Main

 enum class Type {

    PAWN,ROOK,KNIGHT,BISHOP,QUEEN,KING
}